// generated from rosidl_generator_c/resource/idl.h.em
// with input from diagnostic_msgs:srv/AddDiagnostics.idl
// generated code does not contain a copyright notice

#ifndef DIAGNOSTIC_MSGS__SRV__ADD_DIAGNOSTICS_H_
#define DIAGNOSTIC_MSGS__SRV__ADD_DIAGNOSTICS_H_

#include "diagnostic_msgs/srv/detail/add_diagnostics__struct.h"
#include "diagnostic_msgs/srv/detail/add_diagnostics__functions.h"
#include "diagnostic_msgs/srv/detail/add_diagnostics__type_support.h"

#endif  // DIAGNOSTIC_MSGS__SRV__ADD_DIAGNOSTICS_H_
