// generated from rosidl_generator_c/resource/idl.h.em
// with input from example_interfaces:srv/Trigger.idl
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__SRV__TRIGGER_H_
#define EXAMPLE_INTERFACES__SRV__TRIGGER_H_

#include "example_interfaces/srv/detail/trigger__struct.h"
#include "example_interfaces/srv/detail/trigger__functions.h"
#include "example_interfaces/srv/detail/trigger__type_support.h"

#endif  // EXAMPLE_INTERFACES__SRV__TRIGGER_H_
